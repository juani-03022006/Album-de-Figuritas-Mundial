# Corrección: imágenes optimizadas y URLs válidas

Esta corrección evita guardar URLs pesadas o inestables en `Figurita.pathTopic`.

## Archivos a reemplazar

Copiar y reemplazar en tu proyecto:

```txt
APIAlbumMundial/src/seeders/utils/imageResolver.js
APIAlbumMundial/src/services/AlbumService.js
```

## Qué cambia

- Las imágenes reales se piden a Wikimedia/Commons como thumbnails chicos.
- Ya no se guardan URLs tipo `Special:Redirect/file/...` para las figuritas cuando se resuelve lazy.
- Antes de guardar una URL se valida que responda como imagen.
- Los placeholders pasan a ser URLs remotas livianas de `placehold.co`, no data URLs.
- La búsqueda de jugadores se hace con concurrencia limitada para que no sea extremadamente lenta.
- Si la BD vieja tiene URLs lentas de `Special:Redirect/file`, el backend las considera no optimizadas y las vuelve a resolver cuando entrás a esa selección.

## Variables opcionales

```bash
# Por defecto valida URLs antes de guardarlas.
LAZY_IMAGE_VALIDATE=true

# Apagar validación si necesitás máxima velocidad de prueba.
LAZY_IMAGE_VALIDATE=false

# Timeout por validación de URL.
LAZY_IMAGE_VALIDATE_TIMEOUT_MS=1200

# Tamaño de fotos de jugadores.
LAZY_IMAGE_PLAYER_WIDTH=360

# Tamaño de escudo y director técnico.
LAZY_IMAGE_SPECIAL_WIDTH=360

# Tamaño de foto grupal de selección.
LAZY_IMAGE_TEAM_PHOTO_WIDTH=720

# Cantidad de jugadores que resuelve en paralelo por selección.
LAZY_IMAGE_CONCURRENCY=4
```

## Recomendación de uso

No hace falta borrar la base obligatoriamente. Si ya tenés URLs viejas, al entrar a una selección el backend las detecta como no optimizadas y las reemplaza.

Si querés limpiar todo desde cero, borrá la base o dejá `sync({ force: true })` y levantá la API normalmente.

```bash
cd APIAlbumMundial
npm run dev
```

Después entrá desde el frontend a una selección. Esa selección se resolverá con thumbnails validados y mucho más livianos.
