const WIKIDATA_API = 'https://www.wikidata.org/w/api.php';
const COMMONS_API = 'https://commons.wikimedia.org/w/api.php';

const DEFAULT_TIMEOUT_MS = Number(process.env.SEED_IMAGE_TIMEOUT_MS ?? 2500);
const REQUEST_DELAY_MS = Number(process.env.SEED_IMAGE_REQUEST_DELAY_MS ?? 0);
const ENABLE_LOGS = process.env.SEED_IMAGE_LOG === 'true';

// Medidas chicas para que el frontend no cargue fotos enormes.
// El objetivo es que cada figurita use un thumbnail liviano y no el archivo original.
const PLAYER_IMAGE_WIDTH = Number(process.env.LAZY_IMAGE_PLAYER_WIDTH ?? 360);
const SPECIAL_IMAGE_WIDTH = Number(process.env.LAZY_IMAGE_SPECIAL_WIDTH ?? 360);
const TEAM_PHOTO_IMAGE_WIDTH = Number(process.env.LAZY_IMAGE_TEAM_PHOTO_WIDTH ?? 720);
const FLAG_IMAGE_WIDTH = Number(process.env.LAZY_IMAGE_FLAG_WIDTH ?? 180);
const FALLBACK_WIDTH = Number(process.env.LAZY_IMAGE_FALLBACK_WIDTH ?? 360);
const FALLBACK_HEIGHT = Number(process.env.LAZY_IMAGE_FALLBACK_HEIGHT ?? 504);

// Validar cada URL evita guardar links que después el navegador no puede mostrar.
// Si alguna validación te ralentiza mucho mientras desarrollás: LAZY_IMAGE_VALIDATE=false npm run dev
const VALIDATE_REMOTE_IMAGE_URLS = process.env.LAZY_IMAGE_VALIDATE !== 'false';
const URL_VALIDATION_TIMEOUT_MS = Number(process.env.LAZY_IMAGE_VALIDATE_TIMEOUT_MS ?? 1200);

const MAX_CONCURRENT_PLAYER_IMAGE_RESOLVES = Number(
  process.env.LAZY_IMAGE_CONCURRENCY ?? 4
);

const memoryCache = new Map();

function log(...args) {
  if (ENABLE_LOGS) console.log('[seed-images]', ...args);
}

function wait(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function normalizeText(value) {
  return String(value ?? '')
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, ' ')
    .trim();
}

function compact(value) {
  return String(value ?? '').replace(/\s+/g, ' ').trim();
}

function sanitizeHex(value, fallback) {
  const clean = String(value ?? '')
    .replace('#', '')
    .trim();

  return /^[0-9a-fA-F]{6}$/.test(clean) ? clean : fallback;
}

function buildUrl(baseUrl, params) {
  const url = new URL(baseUrl);
  Object.entries(params).forEach(([key, value]) => {
    if (value !== undefined && value !== null) url.searchParams.set(key, value);
  });
  return url.toString();
}

// Se mantiene exportada porque teamVisuals usa el mismo criterio conceptual.
// Esta URL es solamente un fallback. Para las figuritas reales usamos thumburl directo
// desde la API de Commons, que evita redirecciones y archivos pesados.
export function commonsFileUrl(fileName, width = SPECIAL_IMAGE_WIDTH) {
  if (!fileName) return null;
  return buildUrl(`https://commons.wikimedia.org/wiki/Special:Redirect/file/${encodeURIComponent(fileName)}`, {
    width: String(width),
  });
}

export function fallbackImageUrl({
  label,
  teamCode,
  colors = {},
  width = FALLBACK_WIDTH,
  height = FALLBACK_HEIGHT,
}) {
  const bg = sanitizeHex(colors.colorMain, '334155');
  const fg = sanitizeHex(colors.colorText, 'FFFFFF');
  const title = compact(label).slice(0, 34) || 'SIN IMAGEN';
  const subtitle = teamCode ? `PENDIENTE ${teamCode}` : 'PENDIENTE';
  const text = `${title}\n${subtitle}`;

  // Placeholder remoto, liviano y válido. No es una imagen local ni un data URI.
  return `https://placehold.co/${width}x${height}/${bg}/${fg}.svg?font=montserrat&text=${encodeURIComponent(text)}`;
}

async function fetchJson(url, cacheKey) {
  if (memoryCache.has(cacheKey)) return memoryCache.get(cacheKey);

  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), DEFAULT_TIMEOUT_MS);

  try {
    await wait(REQUEST_DELAY_MS);
    const response = await fetch(url, {
      signal: controller.signal,
      headers: {
        'User-Agent': 'AlbumMundialSeeder/1.0 (development; educational project)',
        Accept: 'application/json',
      },
    });

    if (!response.ok) {
      throw new Error(`HTTP ${response.status} al consultar ${url}`);
    }

    const data = await response.json();
    memoryCache.set(cacheKey, data);
    return data;
  } catch (error) {
    log('falló consulta', error.message);
    memoryCache.set(cacheKey, null);
    return null;
  } finally {
    clearTimeout(timeoutId);
  }
}

async function validateImageUrl(url) {
  if (!url) return null;
  if (!VALIDATE_REMOTE_IMAGE_URLS) return url;

  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), URL_VALIDATION_TIMEOUT_MS);

  try {
    const response = await fetch(url, {
      method: 'HEAD',
      redirect: 'follow',
      signal: controller.signal,
      headers: {
        Accept: 'image/avif,image/webp,image/apng,image/svg+xml,image/*,*/*;q=0.8',
        'User-Agent': 'AlbumMundialSeeder/1.0 (development; educational project)',
      },
    });

    const contentType = response.headers.get('content-type') ?? '';
    if (response.ok && contentType.toLowerCase().startsWith('image/')) {
      return response.url || url;
    }
  } catch (error) {
    log('HEAD inválido', error.message);
  } finally {
    clearTimeout(timeoutId);
  }

  // Algunos hosts no aceptan HEAD. Se hace un GET parcial y acotado.
  const getController = new AbortController();
  const getTimeoutId = setTimeout(() => getController.abort(), URL_VALIDATION_TIMEOUT_MS);

  try {
    const response = await fetch(url, {
      method: 'GET',
      redirect: 'follow',
      signal: getController.signal,
      headers: {
        Range: 'bytes=0-512',
        Accept: 'image/avif,image/webp,image/apng,image/svg+xml,image/*,*/*;q=0.8',
        'User-Agent': 'AlbumMundialSeeder/1.0 (development; educational project)',
      },
    });

    const contentType = response.headers.get('content-type') ?? '';
    if ((response.ok || response.status === 206) && contentType.toLowerCase().startsWith('image/')) {
      return response.url || url;
    }
  } catch (error) {
    log('GET parcial inválido', error.message);
  } finally {
    clearTimeout(getTimeoutId);
  }

  return null;
}

async function searchWikidataEntities(query, limit = 5) {
  const cleanQuery = compact(query);
  if (!cleanQuery) return [];

  const url = buildUrl(WIKIDATA_API, {
    action: 'wbsearchentities',
    search: cleanQuery,
    language: 'en',
    uselang: 'en',
    format: 'json',
    limit: String(limit),
    origin: '*',
  });

  const data = await fetchJson(url, `wikidata-search:${cleanQuery}:${limit}`);
  return Array.isArray(data?.search) ? data.search : [];
}

async function getWikidataEntity(id) {
  if (!id) return null;

  const url = buildUrl(WIKIDATA_API, {
    action: 'wbgetentities',
    ids: id,
    props: 'claims|labels|descriptions',
    languages: 'en',
    format: 'json',
    origin: '*',
  });

  const data = await fetchJson(url, `wikidata-entity:${id}`);
  return data?.entities?.[id] ?? null;
}

function getClaimFileName(entity, propertyIds) {
  for (const propertyId of propertyIds) {
    const claim = entity?.claims?.[propertyId]?.find(
      (item) => item?.mainsnak?.datavalue?.type === 'string'
    );
    const fileName = claim?.mainsnak?.datavalue?.value;
    if (fileName) return fileName;
  }

  return null;
}

async function getCommonsThumbnailFromFileName(fileName, width) {
  if (!fileName) return null;

  const cleanFileName = fileName.replace(/^File:/i, '');
  const url = buildUrl(COMMONS_API, {
    action: 'query',
    titles: `File:${cleanFileName}`,
    prop: 'imageinfo',
    iiprop: 'url|mime|size',
    iiurlwidth: String(width),
    format: 'json',
    origin: '*',
  });

  const data = await fetchJson(url, `commons-file:${cleanFileName}:${width}`);
  const page = Object.values(data?.query?.pages ?? {})[0];
  const info = page?.imageinfo?.[0];

  if (!info?.mime?.startsWith('image/')) return null;

  const candidateUrl = info.thumburl ?? info.url;
  const validUrl = await validateImageUrl(candidateUrl);

  if (!validUrl) {
    log('thumbnail inválido', cleanFileName, candidateUrl);
    return null;
  }

  return validUrl;
}

function scoreWikidataCandidate(candidate, hints = []) {
  const label = normalizeText(candidate?.label);
  const description = normalizeText(candidate?.description);
  const aliases = normalizeText((candidate?.aliases ?? []).join(' '));
  const text = `${label} ${description} ${aliases}`;

  let score = 0;
  if (description.includes('football') || description.includes('soccer')) score += 6;
  if (description.includes('association football')) score += 3;
  if (description.includes('player') || description.includes('manager') || description.includes('coach')) score += 2;

  for (const hint of hints.map(normalizeText).filter(Boolean)) {
    if (label === hint) score += 5;
    if (label.includes(hint) || hint.includes(label)) score += 3;
    if (text.includes(hint)) score += 1;
  }

  return score;
}

async function imageFromWikidata({ queries, propertyIds, width, hints = [] }) {
  const candidatesById = new Map();

  for (const query of queries.filter(Boolean)) {
    const results = await searchWikidataEntities(query, 6);
    for (const result of results) {
      if (!result?.id || candidatesById.has(result.id)) continue;
      candidatesById.set(result.id, {
        ...result,
        _score: scoreWikidataCandidate(result, hints),
      });
    }
  }

  const candidates = [...candidatesById.values()].sort((a, b) => b._score - a._score);

  for (const candidate of candidates) {
    const entity = await getWikidataEntity(candidate.id);
    const fileName = getClaimFileName(entity, propertyIds);
    if (!fileName) continue;

    const url = await getCommonsThumbnailFromFileName(fileName, width);
    if (url) {
      log('wikidata', candidate.label, candidate.id, fileName, url);
      return url;
    }
  }

  return null;
}

async function imageFromCommonsSearch({ queries, width }) {
  for (const query of queries.filter(Boolean).map(compact)) {
    const url = buildUrl(COMMONS_API, {
      action: 'query',
      generator: 'search',
      gsrsearch: query,
      gsrnamespace: '6',
      gsrlimit: '8',
      prop: 'imageinfo',
      iiprop: 'url|mime|size',
      iiurlwidth: String(width),
      format: 'json',
      origin: '*',
    });

    const data = await fetchJson(url, `commons-search:${query}:${width}`);
    const pages = Object.values(data?.query?.pages ?? {});

    for (const page of pages) {
      const info = page?.imageinfo?.[0];
      const candidateUrl = info?.thumburl ?? info?.url;
      if (!info?.mime?.startsWith('image/') || !candidateUrl) continue;

      const validUrl = await validateImageUrl(candidateUrl);
      if (validUrl) {
        log('commons', query, validUrl);
        return validUrl;
      }
    }
  }

  return null;
}

async function mapWithConcurrency(items, concurrency, mapper) {
  const results = new Array(items.length);
  let nextIndex = 0;

  const workers = Array.from({ length: Math.min(concurrency, items.length) }, async () => {
    while (nextIndex < items.length) {
      const currentIndex = nextIndex;
      nextIndex += 1;
      results[currentIndex] = await mapper(items[currentIndex], currentIndex);
    }
  });

  await Promise.all(workers);
  return results;
}

function playerSearchQueries(player, team) {
  const fullName = compact(`${player.nombre} ${player.apellido}`);
  const fifaName = compact(player.nombreCompletoFifa);
  const searchName = team.visuals?.searchName ?? `${team.nombre} national football team`;

  return [
    `${fullName} footballer`,
    `${fifaName} footballer`,
    `${fullName} ${searchName}`,
    `${player.nombreCamiseta ?? player.apellido} ${team.nombre} footballer`,
  ];
}

function coachSearchQueries(team) {
  const coach = team.directorTecnico;
  const fullName = compact(`${coach?.nombre ?? ''} ${coach?.apellido ?? ''}`) || coach?.nombreCompleto;
  return [
    `${fullName} football manager`,
    `${coach?.nombreCompleto ?? fullName} football coach`,
    `${fullName} ${team.visuals?.searchName ?? team.nombre}`,
  ];
}

export async function resolvePlayerImageUrl(player, team) {
  const fullName = compact(`${player.nombre} ${player.apellido}`);

  const wikidataUrl = await imageFromWikidata({
    queries: playerSearchQueries(player, team),
    propertyIds: ['P18'],
    width: PLAYER_IMAGE_WIDTH,
    hints: [fullName, player.nombreCompletoFifa, player.nombreCamiseta],
  });

  if (wikidataUrl) return wikidataUrl;

  return imageFromCommonsSearch({
    queries: playerSearchQueries(player, team),
    width: PLAYER_IMAGE_WIDTH,
  });
}

export async function resolveCoachImageUrl(team) {
  const fullName = team.directorTecnico?.nombreCompleto ?? 'Director técnico';

  const wikidataUrl = await imageFromWikidata({
    queries: coachSearchQueries(team),
    propertyIds: ['P18'],
    width: SPECIAL_IMAGE_WIDTH,
    hints: [fullName, team.directorTecnico?.apellido],
  });

  if (wikidataUrl) return wikidataUrl;

  return imageFromCommonsSearch({ queries: coachSearchQueries(team), width: SPECIAL_IMAGE_WIDTH });
}

export async function resolveTeamShieldUrl(team) {
  const searchName = team.visuals?.searchName ?? `${team.nombre} national football team`;

  const wikidataUrl = await imageFromWikidata({
    queries: [searchName, `${searchName} logo`, `${searchName} badge`, `${team.nombre} football association logo`],
    propertyIds: ['P154', 'P18', 'P41'],
    width: SPECIAL_IMAGE_WIDTH,
    hints: [searchName, team.nombre],
  });

  if (wikidataUrl) return wikidataUrl;

  return imageFromCommonsSearch({
    queries: [`${searchName} logo`, `${searchName} badge`, `${team.nombre} football federation logo`],
    width: SPECIAL_IMAGE_WIDTH,
  });
}

export async function resolveTeamPhotoUrl(team) {
  const searchName = team.visuals?.searchName ?? `${team.nombre} national football team`;

  const commonsUrl = await imageFromCommonsSearch({
    queries: [
      `${searchName} squad`,
      `${searchName} team photo`,
      `${searchName} players`,
      `${searchName}`,
    ],
    width: TEAM_PHOTO_IMAGE_WIDTH,
  });

  if (commonsUrl) return commonsUrl;

  return imageFromWikidata({
    queries: [searchName],
    propertyIds: ['P18'],
    width: TEAM_PHOTO_IMAGE_WIDTH,
    hints: [searchName, team.nombre],
  });
}

export async function resolveTeamFlagUrl(team) {
  if (team.visuals?.flagUrl) {
    const validVisualFlag = await validateImageUrl(team.visuals.flagUrl);
    if (validVisualFlag) return validVisualFlag;
  }

  return imageFromWikidata({
    queries: [team.nombre, `${team.nombre} country`, `${team.nombre} flag`],
    propertyIds: ['P41'],
    width: FLAG_IMAGE_WIDTH,
    hints: [team.nombre],
  });
}

export async function resolveStickerImagesForTeam(team) {
  const colors = team.visuals ?? {};

  const playerEntries = await mapWithConcurrency(
    team.plantel,
    MAX_CONCURRENT_PLAYER_IMAGE_RESOLVES,
    async (player) => {
      const label = compact(`${player.nombre} ${player.apellido}`);
      const remoteUrl = await resolvePlayerImageUrl(player, team);
      return [
        player.numeroCamiseta,
        remoteUrl ?? fallbackImageUrl({ label, teamCode: team.codigo, colors }),
      ];
    }
  );

  const playerImages = Object.fromEntries(playerEntries);

  const [escudoRemoteUrl, fotoEquipoRemoteUrl, tecnicoRemoteUrl, flagRemoteUrl] =
    await Promise.all([
      resolveTeamShieldUrl(team),
      resolveTeamPhotoUrl(team),
      resolveCoachImageUrl(team),
      resolveTeamFlagUrl(team),
    ]);

  const escudoUrl =
    escudoRemoteUrl ??
    fallbackImageUrl({ label: `Escudo ${team.nombre}`, teamCode: team.codigo, colors });

  const fotoEquipoUrl =
    fotoEquipoRemoteUrl ??
    fallbackImageUrl({
      label: `Selección ${team.nombre}`,
      teamCode: team.codigo,
      colors,
      width: TEAM_PHOTO_IMAGE_WIDTH,
      height: Math.round(TEAM_PHOTO_IMAGE_WIDTH * 0.62),
    });

  const tecnicoUrl =
    tecnicoRemoteUrl ??
    fallbackImageUrl({
      label: team.directorTecnico?.nombreCompleto ?? 'Director técnico',
      teamCode: team.codigo,
      colors,
    });

  const flagUrl =
    flagRemoteUrl ??
    fallbackImageUrl({
      label: team.codigo,
      teamCode: team.codigo,
      colors,
      width: FLAG_IMAGE_WIDTH,
      height: Math.round(FLAG_IMAGE_WIDTH * 0.68),
    });

  return {
    flagUrl,
    players: playerImages,
    specials: {
      escudo: escudoUrl,
      foto_equipo: fotoEquipoUrl,
      tecnico: tecnicoUrl,
    },
  };
}

export function buildFallbackStickerImagesForTeam(team) {
  const colors = team.visuals ?? {};
  const playerImages = Object.fromEntries(
    team.plantel.map((player) => [
      player.numeroCamiseta,
      fallbackImageUrl({
        label: compact(`${player.nombre} ${player.apellido}`),
        teamCode: team.codigo,
        colors,
      }),
    ])
  );

  return {
    flagUrl:
      team.visuals?.flagUrl ??
      fallbackImageUrl({
        label: team.codigo,
        teamCode: team.codigo,
        colors,
        width: FLAG_IMAGE_WIDTH,
        height: Math.round(FLAG_IMAGE_WIDTH * 0.68),
      }),
    players: playerImages,
    specials: {
      escudo:
        team.visuals?.flagUrl ??
        fallbackImageUrl({ label: `Escudo ${team.nombre}`, teamCode: team.codigo, colors }),
      foto_equipo: fallbackImageUrl({
        label: `Selección ${team.nombre}`,
        teamCode: team.codigo,
        colors,
        width: TEAM_PHOTO_IMAGE_WIDTH,
        height: Math.round(TEAM_PHOTO_IMAGE_WIDTH * 0.62),
      }),
      tecnico: fallbackImageUrl({
        label: team.directorTecnico?.nombreCompleto ?? 'Director técnico',
        teamCode: team.codigo,
        colors,
      }),
    },
  };
}
